#!/bin/sh

make install

